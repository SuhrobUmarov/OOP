package com.example.mvcpluscontrollers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvCplusControllersApplicationTests {

    @Test
    void contextLoads() {
    }

}
