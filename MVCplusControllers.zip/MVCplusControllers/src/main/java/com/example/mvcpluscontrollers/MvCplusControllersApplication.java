package com.example.mvcpluscontrollers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvCplusControllersApplication {

    public static void main(String[] args) {
        SpringApplication.run(MvCplusControllersApplication.class, args);
    }

}
